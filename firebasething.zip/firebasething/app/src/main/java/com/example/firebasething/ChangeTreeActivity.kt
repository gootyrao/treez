package com.example.firebasething

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ChangeTreeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_tree)
    }
}