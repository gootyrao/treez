package com.example.firebasething

data class Tree(val location: String = "", val species: String = "", val leafColor: String = "",
                val barkColor: String = "",val rating: String = "")
