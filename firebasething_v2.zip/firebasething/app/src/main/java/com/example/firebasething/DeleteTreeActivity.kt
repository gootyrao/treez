package com.example.firebasething

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class DeleteTreeActivity : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var buttonDeleteTree: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_delete_tree)

        buttonDeleteTree.setOnClickListener {
            deleteTree()
            //how to get treeID
        }
    }

    private fun deleteTree(id:String) {
        val db = FirebaseDatabase.getInstance().getReference("treez").child(id)
        db.removeValue()

        Toast.makeText(applicationContext, "Tree Deleted", Toast.LENGTH_LONG).show()

    }
}