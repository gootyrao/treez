package com.example.firebasething

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class ChangeTreeActivity : AppCompatActivity() {

    private lateinit var editTreeName: EditText
    private lateinit var editTreeType: EditText
    private lateinit var buttonChangeTree: Button
    private lateinit var editLeafColor: EditText
    private lateinit var editTrunkColor: EditText
    private lateinit var editLocation: EditText

    private lateinit var database: DatabaseReference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_tree)
        database = Firebase.database.reference

        buttonChangeTree.setOnClickListener {
            val id = FirebaseDatabase.getInstance().getReference()
                .child("quotes").child();
            updateTree()
            //how to get treeID
        }
    }

    private fun updateTree(id:String) {

        val name = editTreeName.text.toString().trim {it <= ' '}
        val type = editTreeType.text.toString().trim {it <= ' '}
        val leaf = editLeafColor.text.toString().trim {it <= ' '}
        val trunk = editTrunkColor.text.toString().trim {it <= ' '}
        val location = editLocation.text.toString().trim {it <= ' '}

        if (!TextUtils.isEmpty(name) || !TextUtils.isEmpty(leaf) ||
            !TextUtils.isEmpty(location) || !TextUtils.isEmpty(type) ||
            !TextUtils.isEmpty(trunk)) {

            val db = FirebaseDatabase.getInstance().getReference("treez").child(id)
            val tree = Tree(id, name, type, leaf, trunk, location)
            //val d = FirebaseDatabase.getInstance().getReference("treez").child(id)
            //database.child("treez").child(id).setValue(tree)
            db.setValue(tree)

            editTreeName.setText("")
            editTreeType.setText("")
            editLeafColor.setText("")
            editTrunkColor.setText("")
            editLocation.setText("")

            Toast.makeText(this, "Tree Changed", Toast.LENGTH_SHORT).show()
        }
        else {
            Toast.makeText(this, "Please fill in all values ", Toast.LENGTH_SHORT).show()
        }
    }

}

