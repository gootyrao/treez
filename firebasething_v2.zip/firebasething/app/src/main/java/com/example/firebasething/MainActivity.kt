package com.example.firebasething

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var editTreeName: EditText
    private lateinit var editTreeType: EditText
    private lateinit var buttonAddTree: Button
    private lateinit var editLeafColor: EditText
    private lateinit var editTrunkColor: EditText
    private lateinit var editLocation: EditText
    private lateinit var buttonChangeTree: Button
    private lateinit var buttonDeleteTree: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //database = FirebaseDatabase.getInstance().getReference("")
        database = Firebase.database.reference

        buttonAddTree.setOnClickListener {
            addTree()
        }
    }

    public fun gotoLogin(view: View) {
        startActivity(Intent(this, LoginActivity::class.java))
    }

    public fun gotoReg(view: View) {
        startActivity(Intent(this, RegistrationActivity::class.java))
    }

    private fun addTree() {
        val name = editTreeName.text.toString().trim {it <= ' '}
        val type = editTreeType.text.toString().trim {it <= ' '}
        val leaf = editLeafColor.text.toString().trim {it <= ' '}
        val trunk = editTrunkColor.text.toString().trim {it <= ' '}
        val location = editLocation.text.toString().trim {it <= ' '}

        if (!TextUtils.isEmpty(name) || !TextUtils.isEmpty(leaf) ||
            !TextUtils.isEmpty(location) || !TextUtils.isEmpty(type) ||
            !TextUtils.isEmpty(trunk)) {
            val id = database.push().key

            val tree = Tree(id!!, name, type, leaf, trunk, location)
            //database.child("treez").child(id).setValue(tree)
            database.child(id).setValue(tree)

            editTreeName.setText("")
            editTreeType.setText("")
            editLeafColor.setText("")
            editTrunkColor.setText("")
            editLocation.setText("")

            Toast.makeText(this, "Tree Added", Toast.LENGTH_SHORT).show()
        }
        else {
            Toast.makeText(this, "Please fill in all values ", Toast.LENGTH_SHORT).show()
        }


    }

    private fun updateTree(id: String, name: String, type: String, leafColor: String,
                           trunkColor: String, location: String): Boolean {
        val db = FirebaseDatabase.getInstance().getReference("treez").child(id)

        val tree = Tree(id, name, type, leafColor, trunkColor, location)
        db.setValue(tree)
        Toast.makeText(applicationContext, "Tree successfully updated", Toast.LENGTH_LONG).show()
        return true
    }

    private fun deleteTree(id: String, name: String, type: String, leafColor: String,
                           trunkColor: String, location: String): Boolean {
        val db = FirebaseDatabase.getInstance().getReference("treez").child(id)
        db.removeValue()

        Toast.makeText(applicationContext, "Tree Deleted", Toast.LENGTH_LONG).show()
    }


}